import React from "react";
import logo from "../UMFyuzed.png";

export class UserDetails extends React.Component {

    constructor(props) {
        super(props);
    }

    continue = e =>{
        e.preventDefault();
        this.props.nextStep();
    }


    render () {
        const { values, handleChange } = this.props;
        return ( 
            <div className="base-container" ref={this.props.containerRef}>

                <div className="content">
                    <div className="image">
                        <img className="logo" src={logo}/>  
                    </div>
                    <div className="Signin">
                        <h2>Register</h2>
                    </div>
                    <div className="form">
                        <div className="form-group">
                            <label className="label" htmlFor="First Name"></label>
                            <input className="input" 
                                type="text" 
                                name="First Name" 
                                placeholder="First Name"
                                onChange={handleChange('firstName')}
                                defaultValue={values.firstName}>
                            </input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="Last Name"></label>
                            <input className="input" 
                                type="text" 
                                name="Last Name" 
                                placeholder="Last name"
                                onChange={handleChange('lastName')}
                                defaultValue={values.lastName}>
                            </input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="email"></label>
                            <input className="input" 
                                type="email" 
                                name="email" 
                                placeholder="email"
                                onChange={handleChange('Email')}
                                defaultValue={values.Email}>
                            </input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="password"></label>
                            <input className="input" 
                                type="password" 
                                name="password" 
                                placeholder="password"
                                onChange={handleChange('Password')}
                                defaultValue={values.Password}>
                            </input>
                        </div>
                    </div>
                </div>
                    
                    <button type="button" 
                    className="btn"
                    onClick={this.continue}>
                        Continue
                    </button>
                  
            </div>
           
        );
    }
}
export default UserDetails