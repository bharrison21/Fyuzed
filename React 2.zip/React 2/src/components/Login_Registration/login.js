import React from "react";
import logo from "./UMFyuzed.png";


export class Login extends React.Component {

    constructor(props) {
        super(props);
    }

    render () {
        return ( 
            <div className="base-container" ref={this.props.containerRef}>
                <div className="content">
                    <div className="image">
                        <img className ="logo" src={logo}/>  
                    </div>
                    <div className="Signin">
                        <h2>Sign In</h2>
                    </div>
                    <div className="form">
                        <div className="form-group">
                            <label className="label" htmlFor="Email"></label>
                            <input className="input" type="email" name="email" placeholder="email"></input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="password"></label>
                            <input className="input" type="password" name="password" placeholder="password"></input>
                        </div>
                    </div>
                </div>
                <div className="footer">
                    <button type="button" className="btn">
                        Login
                    </button>
                </div>
            </div>
        );
    }
}
//for button to next path
//onClick={() => this.nextPath('/the/path')