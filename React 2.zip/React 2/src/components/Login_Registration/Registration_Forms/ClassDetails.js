import React, { Component } from 'react';
import logo from "../UMFyuzed.png";


export class ClassDetails extends Component {

    constructor(props) {
        super(props);
    }
    

    continue = e =>{
        e.preventDefault();
        this.props.nextStep();
    }
    back = e =>{
        e.preventDefault();
        this.props.prevStep();
    }

    render () {
        const { values, handleChange } = this.props;
        return ( 
            <div className="base-container" ref={this.props.containerRef}>

                <div className="content">

                    <div className="image">
                        <img className="logo" src={logo}/>  
                    </div>
                    <div className="Signin">
                        <h2>Welcome, {values.firstName}! </h2>
                    </div>
                    <div className="form">
                        <div className="form-group">
                            <label className="label" htmlFor="year"></label>
                            <input className="input" 
                                type="text" 
                                name="Year" 
                                placeholder="Year (ex: Freshman)"
                                onChange={handleChange('Year')}
                                defaultValue={values.Year}>
                            </input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="major"></label>
                            <input className="input" 
                                type="text" 
                                name="Major" 
                                placeholder="Major or Undecided"
                                onChange={handleChange('Major')}
                                defaultValue={values.Major}>
                            </input>
                        </div>
                        <div className="form-group">
                            <label className="label" htmlFor="minor"></label>
                            <input className="input" 
                                type="text" 
                                name="Minor" 
                                placeholder="Minor"
                                onChange={handleChange('Minor')}
                                defaultValue={values.Minor}>
                            </input>
                        </div>
                    </div>
                </div>
                    <div className="footer">
                    
                        <button type="button" 
                            className="btn"
                            onClick={this.continue}>
                            Continue
                        </button>

                        <button type="button"
                            className="btn"
                            onClick={this.back}>
                            Back
                        </button>
                        
                    </div>
            </div>
        );
    }
    }


    export default ClassDetails