import React from 'react';
import {BrowserRouter as Router , Route} from 'react-router-dom';
import App from './App';
import {Login_Reg} from './pages/Login_Reg/login_registration';



const Routes = (props) => (
    <Router {...props}>
        <Route path="/" component={App}>
            <Route path={[""]} component={Login_Reg} />
            

        </Route>
    </Router>
)

export default Routes;