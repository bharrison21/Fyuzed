import React, { Component } from 'react';
import UserDetails from './UserDetails';
import  ClassDetails from './ClassDetails';

export class Reg extends Component {
    //state of steps and values of what user's input
    state={
        step: 1,
        firstName:'',
        lastName:'',
        Email:'',
        Paaword:'',
        Year:'',
        Major:'',
        Minor:'',
        Classes:[],
        Clubs:[],
    }

    //next step
    nextStep = () => {
        const { step } = this.state;
        this.setState({
            step: step + 1
        });
    }
    //prev step
    prevStep = () => {
        const { step } = this.state;
        this.setState({
        step: step - 1
        });
    }

    //Handle field change
    handleChange = input => e => {
        this.setState({ [input]: e.target.value });
    }
    
    render() {
        const { step } = this.state;
        const { firstName, lastName, Email, Password, Year, Major, Minor} = this.state;
        const values = { firstName, lastName, Email, Password, Year, Major, Minor}
    
        
        switch(step) {
            case 1:
                return (
                    <UserDetails
                        nextStep={this.nextStep}
                        handleChange={this.handleChange}
                        values={values}
                    />
                )
            case 2:
                return(
                    <ClassDetails
                        nextStep={this.nextStep}
                        prevStep={this.prevStep}
                        handleChange={this.handleChange}
                        values={values}
                    />
                )
                
            case 3:
                return(
                    <h1>confirm</h1>
                )
            case 4:
                return(
                    <h1>success</h1>
                )

        }
    }
}


