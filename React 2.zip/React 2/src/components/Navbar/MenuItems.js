export const MenuItems= [
    {
        title: 'Home',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Courses',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Careers',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Clubs',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Social',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Profile',
        //URL will go below
        url: '#',
        cName: 'nav-links',
    },
    {
        title: 'Sign up',
        //URL will go below
        url: '#',
        cName: 'nav-links-mobile',
    },
]