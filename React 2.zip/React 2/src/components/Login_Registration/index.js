import "./style.css";

export { Login } from './login';
export { Reg } from './Registration_Forms/registration_form';